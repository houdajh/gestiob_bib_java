package class_supp;

public class Manga {
}
