package class_supp;

public class DictionnaireBilingue {
}
